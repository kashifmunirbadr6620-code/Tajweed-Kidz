Tajweed Kids - Android Studio APK Guide (اردو اور انگلش):

HOW TO BUILD YOUR .APK IN 1 MINUTE:
1. Extract this .zip folder.
2. Open Android Studio (download free from developer.android.com if not installed).
3. Click "Open" and select this extracted folder.
4. Wait 15 seconds for Gradle sync to complete.
5. In top menu, click: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
6. Done! Android Studio will notify "APK(s) generated successfully" with a "locate" link!
7. Transfer the generated app-debug.apk to any Android phone and install!

طریقہ برائے اینڈرائیڈ اسٹوڈیو:
۱۔ اس زپ فائل کو اپنے کمپیوٹر پر ایکسٹریکٹ کریں۔
۲۔ اینڈرائیڈ اسٹوڈیو کھولیں اور یہ فولڈر اوپن کریں۔
۳۔ مینو میں جا کر Build -> Build APK(s) پر کلک کریں۔
۴۔ آپ کی مکمل .apk فائل فوراً تیار ہو جائے گی جسے کسی بھی فون پر انسٹال کیا جا سکتا ہے!
