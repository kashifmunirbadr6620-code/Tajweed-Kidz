=====================================================
TAJWEED KIDS - ANDROID APK & PLAY STORE BUILD GUIDE
تجوید کڈز - اینڈرائیڈ اے پی کے اور پلے اسٹور گائیڈ
=====================================================

OPTION A: BUILD APK WITHOUT INSTALLING ANDROID STUDIO (FREE VIA GITHUB)
1. Create a free repository on github.com and upload the extracted files from this ZIP.
2. Go to the "Actions" tab in GitHub -> run "Build Android APK & AAB".
3. Download "tajweed-kids-apk" (app-debug.apk) and "tajweed-kids-aab" directly!

OPTION B: BUILD LOCALLY IN ANDROID STUDIO
1. Extract this .zip and open the folder in Android Studio.
2. Wait for Gradle sync to finish.
3. For APK (Direct Phone Install):
   Build -> Build Bundle(s) / APK(s) -> Build APK(s)
4. For AAB (Google Play Store):
   Build -> Generate Signed Bundle / APK... -> Android App Bundle (.aab)

=====================================================
