# Keep WebView JavaScript interfaces and AndroidX classes
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
