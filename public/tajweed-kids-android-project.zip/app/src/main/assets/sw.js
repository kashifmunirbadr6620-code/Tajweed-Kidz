/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "471fb4b137c684e7b3ffcbdcee76de74"
  }, {
    "url": "pwa-512x512.png",
    "revision": "9d414f17151e0b7d1a16c086d588aaa1"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ecb240ae98146f23eba60e3aa6eb6566"
  }, {
    "url": "privacy.html",
    "revision": "95644ec56ffcd3c78e9badaff82cbcb0"
  }, {
    "url": "playstore-icon-512.png",
    "revision": "b5f4cc8db295a0eca4a3843c774f2626"
  }, {
    "url": "playstore-feature-graphic.png",
    "revision": "62b1e2e0e438c7b8da666ce2ac3015b7"
  }, {
    "url": "index.html",
    "revision": "f5f3d8d4c53eaa815f3267d906301aea"
  }, {
    "url": "icon.svg",
    "revision": "af7cd2ab79ce5fc6d537396c7311fe38"
  }, {
    "url": "feature-graphic.svg",
    "revision": "0259569f301c92bd864420679cf999d1"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "84ae32d55e7b141e740e272913b3102c"
  }, {
    "url": "assets/index-DE2xRGv0.css",
    "revision": null
  }, {
    "url": "assets/index-CkX451XJ.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "84ae32d55e7b141e740e272913b3102c"
  }, {
    "url": "icon.svg",
    "revision": "af7cd2ab79ce5fc6d537396c7311fe38"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ecb240ae98146f23eba60e3aa6eb6566"
  }, {
    "url": "pwa-512x512.png",
    "revision": "9d414f17151e0b7d1a16c086d588aaa1"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "471fb4b137c684e7b3ffcbdcee76de74"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b457c039014cd116470d6048e6045f58"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
